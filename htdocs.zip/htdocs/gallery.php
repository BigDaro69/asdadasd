<div class="gallery-section">
    <h2>Galeria Maszyn</h2>
    <div class="gallery">
        <div class="gallery-item">
            <img src="link_do_grafiki_maszyny_1.jpg" alt="Maszyna 1">
            <p>Nazwa Maszyny 1</p>
        </div>
        <div class="gallery-item">
            <img src="link_do_grafiki_maszyny_2.jpg" alt="Maszyna 2">
            <p>Nazwa Maszyny 2</p>
        </div>
        <div class="gallery-item">
            <img src="link_do_grafiki_maszyny_3.jpg" alt="Maszyna 3">
            <p>Nazwa Maszyny 3</p>
        </div>
        <!-- Dodaj więcej maszyn w galerii według potrzeb -->
    </div>
</div>
