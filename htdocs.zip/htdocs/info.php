<div class="info-section">
    <h2>Jak działa aplikacja?</h2>
    <p>
        Nasza aplikacja umożliwia dobór odpowiednich maszyn rolniczych do wykonywania różnych prac polowych. 
        Użytkownik może wybrać rodzaj pracy, podać moc swojego ciągnika oraz wielkość pola. 
        Na podstawie tych danych aplikacja rekomenduje odpowiednie maszyny dostępne w bazie.
    </p>
    <p>
        Aby skorzystać z aplikacji, wystarczy wybrać odpowiednią czynność, wprowadzić dane dotyczące ciągnika i pól, 
        a następnie kliknąć "Szukaj Maszyn".
    </p>
</div>
